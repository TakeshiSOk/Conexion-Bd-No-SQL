const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const Cliente = require("./models/Cliente"); // 👈 AQUÍ ARRIBA

const app = express();
app.use(express.json());
app.use(cors());

// 🔹 CONEXIÓN A MONGODB
mongoose.connect("mongodb+srv://janergomez765_db_user:root@cluster0.papnyk8.mongodb.net/tienda_online")
  .then(() => console.log("Conectado a MongoDB"))
  .catch(err => console.log(err));

// 🔹 RUTA DE PRUEBA
app.get("/", (req, res) => {
  res.send("API funcionando 🚀");
});


// 🔥 CRUD VA AQUÍ (ANTES DEL LISTEN)

// CREATE
app.post("/clientes", async (req, res) => {
  const nuevoCliente = new Cliente(req.body);
  const resultado = await nuevoCliente.save();
  res.json(resultado);
});

// READ
app.get("/clientes", async (req, res) => {
  const clientes = await Cliente.find();
  res.json(clientes);
});

// UPDATE
app.put("/clientes/:id", async (req, res) => {
  const clienteActualizado = await Cliente.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true }
  );
  res.json(clienteActualizado);
});

// DELETE
app.delete("/clientes/:id", async (req, res) => {
  await Cliente.findByIdAndDelete(req.params.id);
  res.json({ mensaje: "Cliente eliminado" });
});


// 🔹 SERVIDOR
app.listen(3000, () => {
  console.log("Servidor corriendo en puerto 3000");
});